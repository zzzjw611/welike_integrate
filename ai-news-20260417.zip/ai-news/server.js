const http = require('http');
const https = require('https');
const fs = require('fs');
const path = require('path');

const KIMI_API_KEY = process.env.KIMI_API_KEY || 'sk-EBECFESD93bZ8lOuuR58FyPE7oS4MRKWanjLWADfw7lZXlnL';
const PORT = 3000;
const SCHEDULE_FILE = path.join(__dirname, 'schedule.json');

/* ── Schedule state ── */
let schedule = { enabled: false, time: '09:00', sections: ['news'], lang: 'zh', token: '', chatId: '', lastSentDate: '' };

function loadSchedule() {
  try {
    if (fs.existsSync(SCHEDULE_FILE))
      schedule = { ...schedule, ...JSON.parse(fs.readFileSync(SCHEDULE_FILE, 'utf8')) };
  } catch(e) {}
}

function saveSchedule() {
  fs.writeFileSync(SCHEDULE_FILE, JSON.stringify(schedule, null, 2));
}

loadSchedule();

/* ── Helpers ── */
function escHtml(s) {
  return String(s || '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

function parseItems(text) {
  const c = text.replace(/```json/g, '').replace(/```/g, '').trim();
  for (const key of ['items', 'timeline', 'trending']) {
    const m = c.match(new RegExp(`"${key}"\\s*:\\s*(\\[[\\s\\S]*)`));
    if (!m) continue;
    let arr = m[1];
    try { return JSON.parse(arr); } catch(e) {}
    const last = arr.lastIndexOf('},');
    if (last !== -1) arr = arr.slice(0, last + 1) + ']';
    else { const lb = arr.lastIndexOf('}'); if (lb !== -1) arr = arr.slice(0, lb + 1) + ']'; }
    try { return JSON.parse(arr); } catch(e) {}
  }
  try { return JSON.parse(c).items || []; } catch(e) {}
  return [];
}

function formatTgMessage(items, section, lang) {
  const labels = {
    news:    { en: 'Daily News',       zh: '每日重要新闻' },
    funding: { en: 'Funding Updates',  zh: '融资动态' },
    growth:  { en: 'Growth Insights',  zh: '增长洞察' },
    tools:   { en: 'AI Tool Picks',    zh: 'AI工具推荐' },
  };
  const label = (labels[section] || {})[lang] || section;
  const dateStr = new Date().toLocaleDateString('zh-CN', { year: 'numeric', month: 'long', day: 'numeric' });
  let msg = `📡 <b>JE Labs AI News</b>\n<b>${label}</b> · ${dateStr}\n\n`;
  (items || []).slice(0, 5).forEach((item, i) => {
    msg += item.url
      ? `<b>${i + 1}. <a href="${escHtml(item.url)}">${escHtml(item.title)}</a></b>\n`
      : `<b>${i + 1}. ${escHtml(item.title)}</b>\n`;
    if (item.summary)  msg += escHtml(item.summary) + '\n';
    if (item.source)   msg += `<i>${escHtml(item.source)}</i>`;
    if (item.category) msg += ` · ${escHtml(item.category)}`;
    msg += '\n\n';
  });
  return msg + '——\n<i>via JE Labs · Internal use only</i>';
}

/* ── Kimi API (server-side) ── */
async function httpsPost(hostname, urlPath, extraHeaders, body) {
  return new Promise((resolve, reject) => {
    const payload = JSON.stringify(body);
    const req = https.request({
      hostname, port: 443, path: urlPath, method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload), ...extraHeaders },
    }, res => {
      let data = '';
      res.on('data', c => data += c);
      res.on('end', () => {
        try { resolve({ status: res.statusCode, body: JSON.parse(data) }); }
        catch { resolve({ status: res.statusCode, body: data }); }
      });
    });
    req.on('error', reject);
    req.write(payload);
    req.end();
  });
}

async function kimiLoop(messages) {
  for (let i = 0; i < 8; i++) {
    const { status, body } = await httpsPost(
      'api.moonshot.cn', '/v1/chat/completions',
      { 'Authorization': `Bearer ${KIMI_API_KEY}` },
      { model: 'moonshot-v1-32k', messages, temperature: 0.3, max_tokens: 4000,
        tools: [{ type: 'builtin_function', function: { name: '$web_search' } }] }
    );
    if (status !== 200) throw new Error(`Kimi ${status}`);
    const choice = body.choices?.[0];
    if (!choice) throw new Error('Empty response');
    if (choice.finish_reason === 'stop') return choice.message?.content || '';
    if (choice.finish_reason === 'tool_calls') {
      messages.push(choice.message);
      for (const tc of choice.message.tool_calls || [])
        messages.push({ role: 'tool', tool_call_id: tc.id, name: tc.function.name, content: tc.function.arguments || '' });
    } else return choice.message?.content || '';
  }
  throw new Error('Kimi loop limit');
}

const SECTION_PROMPTS = {
  news: (today, li) => ({
    sys: `You are a senior AI industry analyst. Today is ${today}. Use web search to find the 5 most consequential AI stories from the past 24-48 hours. ${li} Return ONLY raw JSON: {"items":[{"time":"HH:MM","title":"...","source":"...","url":"...","summary":"2-3 sentences.","background":"2-3 sentences.","category":"Model update","tags":[],"analysis":"..."}]} category: Model update|Research|Funding|Policy|Product`,
    user: `Find the 5 most important AI stories today (${today}). Return only JSON.`,
  }),
  funding: (today, li) => ({
    sys: `You are an AI VC analyst. Today is ${today}. Use web search to find 5 notable AI funding rounds (≥$5M) or acquisitions from the past 7 days. ${li} Return ONLY raw JSON: {"items":[{"time":"","title":"[Company] raises $XM [Stage]","source":"...","url":"...","summary":"...","background":"...","category":"Funding","tags":[],"analysis":"..."}]}`,
    user: `Find the 5 most notable AI funding rounds in the past 7 days (${today}). Return only JSON.`,
  }),
  growth: (today, li) => ({
    sys: `You are a growth strategy analyst. Today is ${today}. Use web search to find 5 notable AI startup growth insights or GTM case studies from the past 2 weeks. Focus on PLG, viral tactics, distribution. ${li} Return ONLY raw JSON: {"items":[{"time":"","title":"...","source":"...","url":"...","summary":"...","background":"...","category":"Research","tags":[],"analysis":"..."}]}`,
    user: `Find 5 AI startup growth strategy insights from the past 2 weeks (${today}). Return only JSON.`,
  }),
  tools: (today, li) => ({
    sys: `You are an AI product curator. Today is ${today}. Use web search to find 5 new AI tools or products launched in the past 2 weeks. ${li} Return ONLY raw JSON: {"items":[{"time":"","title":"...","source":"...","url":"...","summary":"...","background":"...","category":"Product","tags":[],"analysis":"..."}]}`,
    user: `Find 5 new AI tools or products gaining traction recently (${today}). Return only JSON.`,
  }),
};

async function fetchSection(section, today, lang) {
  const li = lang === 'zh'
    ? 'Translate ALL text fields into Simplified Chinese. Keep source names, URLs, category values unchanged.'
    : 'Output all text fields in English.';
  const { sys, user } = SECTION_PROMPTS[section](today, li);
  const raw = await kimiLoop([{ role: 'system', content: sys }, { role: 'user', content: user }]);
  return parseItems(raw);
}

async function runScheduledPush() {
  const today = new Date().toLocaleDateString('en-GB', { year: 'numeric', month: 'long', day: 'numeric' });
  const sections = schedule.sections?.length ? schedule.sections : ['news'];
  console.log(`[Schedule] Pushing sections: ${sections.join(', ')}`);
  for (const section of sections) {
    try {
      const items = await fetchSection(section, today, schedule.lang || 'zh');
      const text  = formatTgMessage(items, section, schedule.lang || 'zh');
      const { body } = await httpsPost('api.telegram.org', `/bot${schedule.token}/sendMessage`, {},
        { chat_id: schedule.chatId, text, parse_mode: 'HTML', disable_web_page_preview: true });
      console.log(body.ok ? `[Schedule] ✓ ${section}` : `[Schedule] ✗ ${section}: ${body.description}`);
    } catch(err) {
      console.error(`[Schedule] ✗ ${section}: ${err.message}`);
    }
  }
}

/* ── Minute-tick scheduler ── */
setInterval(() => {
  if (!schedule.enabled || !schedule.token || !schedule.chatId) return;
  const now  = new Date();
  const hhmm = `${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
  const today = now.toDateString();
  if (hhmm !== schedule.time || schedule.lastSentDate === today) return;
  schedule.lastSentDate = today;
  saveSchedule();
  console.log(`[Schedule] Triggered at ${hhmm}`);
  runScheduledPush();
}, 60000);

/* ── HTTP server ── */
const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');
  if (req.method === 'OPTIONS') { res.writeHead(204); res.end(); return; }

  /* GET /api/schedule */
  if (req.method === 'GET' && req.url === '/api/schedule') {
    const { token: _t, ...safe } = schedule;
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(safe));
    return;
  }

  /* POST /api/schedule */
  if (req.method === 'POST' && req.url === '/api/schedule') {
    let body = '';
    req.on('data', c => body += c);
    req.on('end', () => {
      schedule = { ...schedule, ...JSON.parse(body) };
      saveSchedule();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ ok: true }));
    });
    return;
  }

  /* POST /api/news — proxy to Kimi */
  if (req.method === 'POST' && req.url === '/api/news') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const payload = JSON.parse(body);
      const options = {
        hostname: 'api.moonshot.cn', port: 443, path: '/v1/chat/completions', method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${KIMI_API_KEY}` },
      };
      const kimiReq = https.request(options, kimiRes => {
        let data = '';
        kimiRes.on('data', chunk => data += chunk);
        kimiRes.on('end', () => {
          res.writeHead(kimiRes.statusCode, { 'Content-Type': 'application/json' });
          res.end(data);
        });
      });
      kimiReq.on('error', err => {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      });
      kimiReq.write(JSON.stringify(payload));
      kimiReq.end();
    });
    return;
  }

  /* POST /api/telegram */
  if (req.method === 'POST' && req.url === '/api/telegram') {
    let body = '';
    req.on('data', chunk => body += chunk);
    req.on('end', () => {
      const { token, chatId, text } = JSON.parse(body);
      const payload = JSON.stringify({ chat_id: chatId, text, parse_mode: 'HTML', disable_web_page_preview: true });
      const options = {
        hostname: 'api.telegram.org', port: 443, path: `/bot${token}/sendMessage`, method: 'POST',
        headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(payload) },
      };
      const tgReq = https.request(options, tgRes => {
        let data = '';
        tgRes.on('data', chunk => data += chunk);
        tgRes.on('end', () => {
          res.writeHead(tgRes.statusCode, { 'Content-Type': 'application/json' });
          res.end(data);
        });
      });
      tgReq.on('error', err => {
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      });
      tgReq.write(payload);
      tgReq.end();
    });
    return;
  }

  res.writeHead(404);
  res.end('Not found');
});

server.listen(PORT, () => {
  console.log(`\n✅ JE Labs proxy server running at http://localhost:${PORT}`);
  console.log(`   Open je-labs-news.html in your browser\n`);
});
