JE Labs AI News — 使用说明
==========================

【需要】电脑上安装了 Node.js（没有就去 https://nodejs.org 下载）

【步骤】

1. 打开终端 / 命令行，进入这个文件夹：
   cd 你的路径/je-labs-news

2. 把 server.js 第一行的 API Key 替换成你的 Kimi key：
   const KIMI_API_KEY = 'sk-你的key在这里';

3. 启动代理服务器：
   node server.js

   看到 "✅ JE Labs proxy server running at http://localhost:3000" 就成功了

4. 用浏览器打开 je-labs-news.html 文件

5. 新闻会自动加载（约 15-30 秒，Kimi 在搜索网络）

【注意】
- 每次使用都要先运行 node server.js
- server.js 和 je-labs-news.html 放在同一个文件夹里
- 不要关闭终端窗口，关了服务就停了

